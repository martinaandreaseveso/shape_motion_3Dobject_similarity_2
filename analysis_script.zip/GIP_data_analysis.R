#Load necessary packages
library(lme4)
library(afex)
library(emmeans)
library(ggplot2)
library(dplyr)
library(tidyr)
library(performance)
library(patchwork)
library(ggeffects)

# overall perfomance
perfomance <- final_df %>%
  summarise(
    mean_error_rate = mean(error_rate, na.rm = TRUE) * 100,  # convert to %
    sd_error_rate = sd(error_rate, na.rm = TRUE) * 100,
    mean_rt = mean(RTms, na.rm = TRUE),  # convert to %
    sd_rt = sd(RTms, na.rm = TRUE))
print(perfomance)

# mean error rate and SD by Condition and RelevantDimension
error_summary <- final_df %>%
  group_by(relevant_dimension, condition) %>%
  summarise(
    mean_error_rate = mean(error_rate, na.rm = TRUE) * 100,  # convert to %
    sd_error_rate = sd(error_rate, na.rm = TRUE) * 100,
    n = n(),
    .groups = "drop"
  )
print(error_summary)

#1) preprocessing
# Remove RT outliers
final_df <- final_df %>% filter(RTms >= 200 & RTms <= 3000)
# Convert factors
final_df <- final_df %>%
  mutate(
    Participant = factor(ID),
    Condition = factor(condition, levels = c("Baseline", "Filtering", "Correlation")),
    RelevantDimension = factor(relevant_dimension))

# 2) Macro-level analysis
# Compute MRT & error rates
summary_final_df <- final_df %>%
  group_by(Participant, Condition, RelevantDimension) %>%
  summarise(
    MRT = mean(RTms[accuracy == 1]),
    logMRT = mean(RTms[accuracy == 1]),
    ErrorRate = mean(accuracy == 0),
    .groups = "drop"
  )

# Compute GI and RG
gi_rg_df <- summary_final_df %>%
  select(Participant, Condition, RelevantDimension, MRT, ErrorRate) %>%
  pivot_wider(names_from = Condition, values_from = c(MRT, ErrorRate)) %>%
  mutate(
    GI_RT = MRT_Filtering - MRT_Baseline,
    RG_RT = MRT_Baseline - MRT_Correlation,
    GI_Error = ErrorRate_Filtering - ErrorRate_Baseline,
    RG_Error = ErrorRate_Baseline - ErrorRate_Correlation
  )
gi_rg_summary <- gi_rg_df %>%
  group_by(RelevantDimension) %>%
  summarise(
    GI_RT_mean = mean(GI_RT, na.rm = TRUE),
    GI_RT_SE = sd(GI_RT, na.rm = TRUE) / sqrt(n()),
    RG_RT_mean = mean(RG_RT, na.rm = TRUE),
    RG_RT_SE = sd(RG_RT, na.rm = TRUE) / sqrt(n()),
    GI_Error_mean = mean(GI_Error, na.rm = TRUE),
    GI_Error_SE = sd(GI_Error, na.rm = TRUE) / sqrt(n()),
    RG_Error_mean = mean(RG_Error, na.rm = TRUE),
    RG_Error_SE = sd(RG_Error, na.rm = TRUE) / sqrt(n())
  )

# 3)LMM for RT
library(lme4)
library(sjPlot)
library(ggplot2)
library(emmeans)
library(performance)

lmer_rt <- lmer(RTms ~ Condition*RelevantDimension +
                  Condition + RelevantDimension + 
                  (1+Condition|ID), data = final_df)
summary(lmer_rt)
lmer_noint <-lmer(RTms ~ Condition + RelevantDimension + 
                    (1+Condition|ID), data = final_df)
summary(lmer_noint)
anova(lmer_rt, lmer_noint)
'           npar    AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)    
lmer_noint   11 168942 169024 -84460    168920                         
lmer_rt      13 168912 169009 -84443    168886 34.347  2   3.48e-08 ***'

#plot of the model estimates/OR
library(jtools)
model1_GIP<- plot_model(lmer_rt)+
  theme_apa()+
  geom_hline(yintercept = 0, color = "black", linetype = "solid", linewidth = 0.5) +
  theme(legend.position = "top") +
  ggtitle("b)")
model1_GIP
ggsave("model_GIP_estimates.png", model1_GIP,width =6, height = 4, dpi = 300)

#summary of the model
library(gtsummary)

lmer_rt %>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "int_model_table_GIP.png"
  )
lmer_noint %>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "model_table_GIP.png"
  )
#coeffients
model_metrics <- model_performance(lmer_rt)
model_metrics
"Indices of model performance

AIC       |      AICc |       BIC | R2 (cond.) | R2 (marg.) |   ICC |    RMSE |   Sigma
---------------------------------------------------------------------------------------
1.689e+05 | 1.689e+05 | 1.690e+05 |      0.292 |      0.081 | 0.229 | 204.528 | 205.271"

#to get the actual numbs of the plot
ggeffect(lmer_rt, terms = c("Condition", "RelevantDimension"), type = 'fe')
"
Relevant_dimension: Motion

Condition   | Predicted |         95% CI
----------------------------------------
Baseline    |    817.03 | 776.19, 857.87
Correlation |    746.69 | 702.40, 790.98
Filtering   |    783.92 | 746.49, 821.34

Relevant_dimension: Shape

Condition   | Predicted |         95% CI
----------------------------------------
Baseline    |    657.36 | 616.54, 698.17
Correlation |    656.99 | 612.66, 701.31
Filtering   |    643.25 | 605.82, 680.67
"
#main effects - data
lmer_rt_MEFF <- lmer(RTms ~ Condition + RelevantDimension + 
                       (1+Condition|ID), data = final_df)
summary(lmer_rt_MEFF)
lmer_rt_MEFF2 <- lmer(RTms ~ Condition  + 
                        (1+Condition|ID), data = final_df)
summary(lmer_rt_MEFF2)
anova(lmer_rt_MEFF,lmer_rt_MEFF2)

#main effect - rd
"              npar    AIC    BIC logLik -2*log(L) Chisq Df Pr(>Chisq)    
lmer_rt_MEFF2   10 170226 170301 -85103    170206                        
lmer_rt_MEFF    11 168942 169024 -84460    168920  1286  1  < 2.2e-16 ***"
#main effect c
"               npar    AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)  
lmer_rt_MEFF2    9 168945 169012 -84464    168927                       
lmer_rt_MEFF    11 168942 169024 -84460    168920 6.8387  2    0.03273 *"

#posthoc values
post_learn = emmeans(lmer_rt, pairwise~RelevantDimension*Condition, type = 'response', adjust = 'bonferroni',
                     pbkrtest.limit = 15269, lmerTest.limit = 15269)
results_learn <- post_learn$contrasts %>% rbind()
results_learn 
' contrast                               estimate    SE  df z.ratio p.value
 Motion Baseline - Shape Baseline        159.675  9.00 Inf  17.736  <.0001*
 Motion Baseline - Motion Filtering       33.112 13.80 Inf   2.397  0.2483
 Motion Baseline - Shape Filtering       173.783 13.80 Inf  12.579  <.0001*
 Motion Baseline - Motion Correlation     70.340 14.80 Inf   4.747  <.0001*
 Motion Baseline - Shape Correlation     160.044 14.80 Inf  10.784  <.0001*
 Shape Baseline - Motion Filtering      -126.563 13.80 Inf  -9.173  <.0001*
 Shape Baseline - Shape Filtering         14.108 13.80 Inf   1.023  1.0000
 Shape Baseline - Motion Correlation     -89.335 14.80 Inf  -6.036  <.0001*
 Shape Baseline - Shape Correlation        0.369 14.80 Inf   0.025  1.0000
 Motion Filtering - Shape Filtering      140.671  4.50 Inf  31.293  <.0001*
 Motion Filtering - Motion Correlation    37.228 13.90 Inf   2.682  0.1098
 Motion Filtering - Shape Correlation    126.932 13.90 Inf   9.128  <.0001*
 Shape Filtering - Motion Correlation   -103.442 13.90 Inf  -7.453  <.0001*
 Shape Filtering - Shape Correlation     -13.738 13.90 Inf  -0.988  1.0000
 Motion Correlation - Shape Correlation   89.704  9.01 Inf   9.961  <.0001*'
results_CI_learn <- 
  confint(results_learn)
results_CI_learn
" contrast                               estimate    SE  df asymp.LCL asymp.UCL
 Motion Baseline - Shape Baseline        159.675  9.00 Inf    133.25    186.10
 Motion Baseline - Motion Correlation     70.340 14.80 Inf     26.85    113.83
 Motion Baseline - Shape Correlation     160.044 14.80 Inf    116.48    203.61
 Motion Baseline - Motion Filtering       33.112 13.80 Inf     -7.44     73.66
 Motion Baseline - Shape Filtering       173.783 13.80 Inf    133.24    214.33
 Shape Baseline - Motion Correlation     -89.335 14.80 Inf   -132.78    -45.89
 Shape Baseline - Shape Correlation        0.369 14.80 Inf    -43.14     43.88
 Shape Baseline - Motion Filtering      -126.563 13.80 Inf   -167.06    -86.07
 Shape Baseline - Shape Filtering         14.108 13.80 Inf    -26.38     54.60
 Motion Correlation - Shape Correlation   89.704  9.01 Inf     63.27    116.14
 Motion Correlation - Motion Filtering   -37.228 13.90 Inf    -77.97      3.51
 Motion Correlation - Shape Filtering    103.442 13.90 Inf     62.70    144.18
 Shape Correlation - Motion Filtering   -126.932 13.90 Inf   -167.75    -86.12
 Shape Correlation - Shape Filtering      13.738 13.90 Inf    -27.07     54.55
 Motion Filtering - Shape Filtering      140.671  4.50 Inf    127.48    153.87"
#plot
lmer_RTplot <- plot_model(lmer_rt, type = "eff", 
                          terms = c("Condition", "RelevantDimension"), 
                          dot.size = 3, line.size = 0.5, alpha = 0.3) +
  aes(shape = group) +   # only works if "group" is in the data
  theme_apa() +
  scale_fill_manual(values = c("#56B4E9","#E69F00")) +
  scale_color_manual(values = c("#56B4E9","#E69F00")) +  
  labs(x = "Classification Condition", 
       y = "Reaction Times (ms)", 
       title = "a)") +
  ylim(c(500,1000)) +
  theme(legend.position = "none") +
  scale_shape_manual(values =sbShape)
lmer_RTplot
setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\GIP\\lmer")
ggsave('RTmodel_interaction.jpg', lmer_RTplot, width =5, height =4, dpi = 300)

suppl_figure <- ggarrange(lmer_RTplot,model1_GIP, nrow=1, ncol=2, widths = c(1, 1.5))
suppl_figure
ggsave('RTmodel_interaction.jpg', suppl_figure, width = 10, height =4, dpi = 300)

#4) GLMM for error_rate
lmer_acc <- glmer(error_rate ~ Condition*RelevantDimension +
                   Condition + RelevantDimension + 
                   (1|ID),family = binomial,data = final_df)
summary(lmer_acc)
lmer_noint <- glmer(error_rate ~ Condition + RelevantDimension + 
                     (1|ID), family = binomial,data = final_df)
summary(lmer_noint)
anova(lmer_acc, lmer_noint)
'           npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)  
lmer_noint    5 3447.8 3485.0 -1718.9    3437.8                       
lmer_acc      7 3442.9 3494.9 -1714.4    3428.9 8.9738  2    0.01126 *'
#main effects - data
lmer_acc_MEFF2 <- glmer(error_rate ~  RelevantDimension + 
                         (1|ID), family = binomial,data = final_df)
summary(lmer_acc_MEFF2)
anova(lmer_noint,lmer_acc_MEFF2)
#me - c
"               npar    AIC    BIC  logLik -2*log(L) Chisq Df Pr(>Chisq)  
lmer_acc_MEFF2    3 3451.5 3473.8 -1722.8    3445.5                      
lmer_noint        5 3447.8 3485.0 -1718.9    3437.8 7.715  2    0.02112 *"
#me-rd no sign
"              npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)
lmer_acc_MEFF2    4 3446.9 3476.6 -1719.5    3438.9                     
lmer_noint        5 3447.8 3485.0 -1718.9    3437.8 1.0676  1     0.3015"

#post hoc
#5) Post-hoc comparisons
library(emmeans)
emmeans(rt_model, pairwise ~ Condition | RelevantDimension)
emmeans(acc_model, pairwise ~ Condition | RelevantDimension)


post_learn = emmeans(lmer_acc, pairwise~RelevantDimension*Condition, type = 'response', adjust = 'bonferroni')
results_learn <- post_learn$contrasts %>% rbind()
results_learn 
' contrast                               odds.ratio    SE  df null z.ratio p.value
 Motion Baseline / Shape Baseline            0.602 0.158 Inf    1  -1.934  0.7962
 Motion Baseline / Motion Correlation        0.443 0.127 Inf    1  -2.832  0.0694
 Motion Baseline / Shape Correlation         0.844 0.203 Inf    1  -0.703  1.0000
 Motion Baseline / Motion Filtering          0.884 0.163 Inf    1  -0.665  1.0000
 Motion Baseline / Shape Filtering           1.020 0.186 Inf    1   0.109  1.0000
 Shape Baseline / Motion Correlation         0.737 0.231 Inf    1  -0.975  1.0000
 Shape Baseline / Shape Correlation          1.403 0.380 Inf    1   1.250  1.0000
 Shape Baseline / Motion Filtering           1.470 0.328 Inf    1   1.729  1.0000
 Shape Baseline / Shape Filtering            1.695 0.375 Inf    1   2.390  0.2530
 Motion Correlation / Shape Correlation      1.904 0.562 Inf    1   2.184  0.4346
 Motion Correlation / Motion Filtering       1.995 0.501 Inf    1   2.747  0.0903
 Motion Correlation / Shape Filtering        2.301 0.574 Inf    1   3.338  0.0127+
 Shape Correlation / Motion Filtering        1.047 0.206 Inf    1   0.236  1.0000
 Shape Correlation / Shape Filtering         1.208 0.235 Inf    1   0.973  1.0000
 Motion Filtering / Shape Filtering          1.153 0.136 Inf    1   1.208  1.0000'

lmer_accplot<- plot_model(lmer_acc, type = "eff", terms = c("Condition","Relevant_dimension"), dot.size = 3, line.size = 0.5, alpha = 0.3) +
  geom_line()+
  theme_classic()+
  labs(x ="Conditions",y="Reaction times", title= "Accuracy predicted by Relevant_dimension and Condition")+
  ylim(c(0.80,1))+
  theme(legend.position = "top")
lmer_accplot
ggsave('model_interaction_acc.jpg', lmer_accplot, width = 6, height = 6, dpi = 300)

#6) Speed–accuracy tradeoff
speed_acc <- summary_final_df %>%
  group_by(Participant) %>%
  summarise(MRT = mean(MRT), ErrorRate = mean(ErrorRate))
cor.test(speed_acc$MRT, speed_acc$ErrorRate)

#7) Plots #####
library(dplyr)
library(ggplot2)
library(patchwork)

# 1. Compute SE for MRT and ErrorRate
se_summary_df <- final_df %>%
  group_by(Participant, Condition, RelevantDimension) %>%
  summarise(
    MRT = mean(RTms[accuracy == 1], na.rm = TRUE),
    ErrorRate = mean(accuracy == 0, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  group_by(Condition, RelevantDimension) %>%
  summarise(
    MRT = mean(MRT, na.rm = TRUE),
    MRT_SE = sd(MRT, na.rm = TRUE) / sqrt(n()),
    ErrorRate = mean(ErrorRate, na.rm = TRUE),
    ErrorRate_SE = sd(ErrorRate, na.rm = TRUE) / sqrt(n()),
    .groups = "drop"
  )
# 2. Compute GI and RG per participant (RT and ErrorRate)
gi_rg_df <- final_df %>%
  group_by(Participant, Condition, RelevantDimension) %>%
  summarise(
    MRT = mean(RTms[accuracy == 1], na.rm = TRUE),
    ErrorRate = mean(accuracy == 0, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  pivot_wider(names_from = Condition, values_from = c(MRT, ErrorRate)) %>%
  mutate(
    GI_RT = MRT_Filtering - MRT_Baseline,
    RG_RT = MRT_Baseline - MRT_Correlation,
    GI_Error = ErrorRate_Filtering - ErrorRate_Baseline,
    RG_Error = ErrorRate_Baseline - ErrorRate_Correlation
  )
# 3. Create plots
cbPalette <- c("Shape" = "#E69F00",  # orange
               "Motion" = "#56B4E9") # blue
sbShape <- c("Motion" = 16, 
             "Shape" = 17) 

# Row 1: Mean RT & Error Rate
p1 <- ggplot(se_summary_df, aes(Condition, MRT, fill = RelevantDimension)) +
  geom_bar(stat = "identity", position = position_dodge(0.9)) +
  geom_errorbar(aes(ymin = MRT - MRT_SE, ymax = MRT + MRT_SE),
                position = position_dodge(0.9), width = 0.2) +
  labs(y = "Mean RT (ms)", title = "A)") +
  scale_fill_manual(values = cbPalette) +
  theme_apa() +
  ylim(0, 1000)

p2 <- ggplot(se_summary_df, aes(Condition, ErrorRate, fill = RelevantDimension)) +
  geom_bar(stat = "identity", position = position_dodge(0.9)) +
  geom_errorbar(aes(ymin = ErrorRate - ErrorRate_SE, ymax = ErrorRate + ErrorRate_SE),
                position = position_dodge(0.9), width = 0.2) +
  labs(y = "Error Rate", title = "B)") +
  scale_fill_manual(values = cbPalette) +
  theme_apa() +
  ylim(0, 0.10)

# Row 2: Garner Interference (RT & Error)
p3 <- ggplot(gi_rg_df, aes(RelevantDimension, GI_RT, fill = RelevantDimension)) +
  geom_boxplot() +
  labs(y = "GI (ms)", title = "C)") +
  scale_fill_manual(values = cbPalette) +
  theme_apa()

p4 <- ggplot(gi_rg_df, aes(RelevantDimension, GI_Error, fill = RelevantDimension)) +
  geom_boxplot() +
  labs(y = "GI (Error Rate)", title = "D)") +
  scale_fill_manual(values = cbPalette) +
  theme_apa()

# Row 3: Redundancy Gain (RT & Error)
p5 <- ggplot(gi_rg_df, aes(RelevantDimension, RG_RT, fill = RelevantDimension)) +
  geom_boxplot() +
  labs(y = "RG (ms)", title = "E)") +
  scale_fill_manual(values = cbPalette) +
  theme_apa()

p6 <- ggplot(gi_rg_df, aes(RelevantDimension, RG_Error, fill = RelevantDimension)) +
  geom_boxplot() +
  labs(y = "RG (Error Rate)", title = "F)") +
  scale_fill_manual(values = cbPalette) +
  theme_apa()

# 4. Combine all into a 3-row, 2-column layout
(p1 | p2) / (p3 | p4) / (p5 | p6)

#Per-participant summary
participant_df <- final_df %>%
  group_by(Participant, Condition, RelevantDimension) %>%
  summarise(
    MRT = mean(RTms[accuracy == 1], na.rm = TRUE),
    ErrorRate = mean(accuracy == 0, na.rm = TRUE),
    .groups = "drop"
  )


p1 <- ggplot(participant_df, aes(Condition, MRT, color = RelevantDimension,shape = RelevantDimension)) +
  stat_summary(fun = mean, geom = "point", size =2.5, position = position_dodge(0.3)) +
  stat_summary(fun.data = mean_cl_normal, geom = "errorbar", width = 0.2, position = position_dodge(0.3)) +
  labs(y = "Mean RT (ms)",x = "Relevant Dimension", title = "A)") +
  scale_color_manual(values = cbPalette) +
  scale_shape_manual(values =sbShape )+
  theme_apa() +
  ylim(0, 1000)
p1
p2 <- ggplot(participant_df, aes(Condition, ErrorRate, color = RelevantDimension, shape = RelevantDimension)) +
  stat_summary(fun = mean, geom = "point", size = 3, position = position_dodge(0.3)) +
  stat_summary(fun.data = mean_cl_normal, geom = "errorbar", width = 0.02, position = position_dodge(0.3)) +
  labs(y = "Error Rate", title = "B)") +
  scale_color_manual(values = cbPalette) +
  scale_shape_manual(values =sbShape )+
  theme_apa() +
  ylim(0, 0.10)
p2
# Row 2: Garner Interference (RT & Error)
p3 <- ggplot(gi_rg_df, aes(RelevantDimension, GI_RT, color = RelevantDimension,shape = RelevantDimension)) +
  stat_summary(fun = mean, geom = "point", size = 3, position = position_dodge(0.2)) +
  stat_summary(fun.data = mean_cl_normal, geom = "errorbar", width = 0.2, position = position_dodge(0.2)) +
  geom_jitter(width = 0.1, alpha = 0.2) +
  labs(y = "GI (ms)", x = "Relevant Dimension",title = "b)") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  scale_color_manual(values = cbPalette) +
  scale_shape_manual(values =sbShape )+
  theme_apa() + 
  ylim(-350, 350)
p3
p4 <- ggplot(gi_rg_df, aes(RelevantDimension, GI_Error, color = RelevantDimension,shape = RelevantDimension)) +
  stat_summary(fun = mean, geom = "point", size = 3, position = position_dodge(0.2)) +
  stat_summary(fun.data = mean_cl_normal, geom = "errorbar", width = 0.02, position = position_dodge(0.2)) +
  geom_jitter(width = 0.1, alpha = 0.2) +
  labs(y = "GI (Error Rate)",x = "Relevant Dimension", title = "c)") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  scale_color_manual(values = cbPalette) +
  scale_shape_manual(values =sbShape )+
  theme_apa()+ ylim(-0.05, 0.05)
p4
# Row 3: Redundancy Gain (RT & Error)
p5 <- ggplot(gi_rg_df, aes(RelevantDimension, RG_RT, color = RelevantDimension,shape = RelevantDimension)) +
  stat_summary(fun = mean, geom = "point", size = 3, position = position_dodge(0.2)) +
  stat_summary(fun.data = mean_cl_normal, geom = "errorbar", width = 0.2, position = position_dodge(0.2)) +
  geom_jitter(width = 0.1, alpha = 0.2) +
  labs(y = "RG (ms)",x = "Relevant Dimension", title = "d)") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  scale_color_manual(values = cbPalette) +
  scale_shape_manual(values =sbShape )+
  theme_apa() +
  ylim(-350, 350)
p5
p6 <- ggplot(gi_rg_df, aes(RelevantDimension, RG_Error, color = RelevantDimension,shape = RelevantDimension)) +
  stat_summary(fun = mean, geom = "point", size = 3, position = position_dodge(0.2)) +
  stat_summary(fun.data = mean_cl_normal, geom = "errorbar", width = 0.02, position = position_dodge(0.2)) +
  geom_jitter(width = 0.1, alpha = 0.2) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  labs(y = "RG (Error Rate)",x = "Relevant Dimension", title = "e)") +
  scale_color_manual(values = cbPalette) +
  scale_shape_manual(values =sbShape )+
  theme_apa()+ ylim(-0.05, 0.05)
p6

# 4. Combine all into a 3-row, 2-column layout
p3 <- p3 + guides(fill = "none", linetype = "none", size = "none")
p4 <- p4 + guides(fill = "none", linetype = "none", size = "none")

final_plot <- (lmer_RTplot) / (p3 | p4) / (p5 | p6) +
  plot_layout(guides = "collect") &
  theme(legend.position = "bottom")
final_plot
ggsave("garner_analysis_plots_APA_2.png", final_plot, width = 5, height = 8)

