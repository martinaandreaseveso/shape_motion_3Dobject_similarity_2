###for general functions####
library(broom)
library(car)
library(caret)
library(plyr)
library(psych)
library(tidyverse)
library(dplyr)
library(reshape2)
library(qwraps2) 
library(devtools)
library(tidytext)
library(rstatix)
library(fmsb)
library(rcompanion)
library(Rmisc)
#for sample matching 
library(MatchIt)
library(optmatch)
#for plotting
library(cowplot)
library(dotwhisker)
library(GGally)
library(ggeffects)
library(gridExtra)
library(ggpubr)
library(jtools)
library(sjPlot)
library(effects)
library(latticeExtra)
library(corrplot)
library(RColorBrewer)
library(jcolors)
library(plotly)
library(gplots)
library(ggthemes)
library(ggstance)
library(dplyr)
library(stats)
#remotes::install_github("ricardo-bion/ggradar")
library(ggradar)
library(networkD3)
library(wesanderson)
#for K means clustering and analyses 
library(kml)
library(kml3d)
library(ez)
library(lme4)
library(emmeans)
library(DHARMa)
library(performance)
library(broom.mixed)
library(jtools)
#for model convergence issues 
library(optimx)
library(parallel)
library(minqa) 
#for MDS
library(magrittr)
library(dplyr)
library(ggpubr)
library(MASS)
library(factoextra)
library(NbClust)


####Data cleaning####
getwd()
setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\GIP\\data_JUNE")
setwd("C:\\Users\\marti\\OneDrive - TCDUD.onmicrosoft.com\\Documents\\Studies\\Data\\MOC_mov\\GIP\\data_JUNE")
#load in datafiles to global environment from working directory - 
#make sure these files are in the same directory then import csv
temp = list.files(pattern="*.csv")
for (i in 1:length(temp)) assign(temp[i], read.csv(temp[i]))
objs <- mget(ls(envir = globalenv()))
dfs <- objs[map_lgl(objs, is.data.frame)]
#if not convergin - trasnfom variables before
dfs <- lapply(dfs, function(df) {
  df %>%
    mutate(
      key_resp_motion_instr.duration = as.character(key_resp_motion_instr.duration),
      participant = as.character(participant),
      session = as.character(session),
      key_resp_shapeF.duration = as.character(key_resp_shapeF.duration),
      key_resp_motionF.duration = as.character(key_resp_motionF.duration)
    )
})
#merge the different datafiles 
gip_data <- reduce(dfs, full_join)
gip_data$participant <- as.factor(gip_data$participant)
table(gip_data$participant)

#Demographics
names(gip_data)
#create a list of columns we want called 'cols'
cols <- c('participant', 'demographic.Sex', 'demographic.Age' ,'demographic.normalvision', 'demographic.normal.hearing', 
          'demographic.Education', 'demographic.Level.Education', 'demographic.Browser' )
#match the names in cols to the column names in the datafile and extract them
demog <- gip_data[cols]
#remove duplicate columns and NA columns 
m_demo2 <- demog[!duplicated(demog), ]
demogfinal <- m_demo2[complete.cases(m_demo2),]
demog$participant <- as.factor(demog$participant)
levels(demogfinal$participant)  
demog <- demogfinal

colnames(demog)[1] <- 'ID'
colnames(demog)[2] <- 'sex'
colnames(demog)[3] <- 'age'
colnames(demog)[4] <- 'normal_vision'
colnames(demog)[5] <- 'normal_hearing'
colnames(demog)[6] <- 'completed_edu'
colnames(demog)[7] <- 'level_edu'
colnames(demog)[8] <- 'browser'

demog$sex <- as.factor(demog$sex)
demog$age <- as.integer(demog$age)
demog$normal_vision <- as.factor(demog$normal_vision)
demog$normal_hearing <- as.factor(demog$normal_hearing)
demog$completed_edu <- as.factor(demog$completed_edu)
demog$level_edu <- as.factor(demog$level_edu)
demog$browser <- as.factor(demog$browser)
#logic
levels(demog$sex)<- c('Male', 'Female')
levels(demog$normal_vision)<-  c('No', 'Yes')
levels(demog$normal_hearing)<-  c('Yes')
levels(demog$completed_edu) <- c('No','Yes')
levels(demog$level_edu)<- c('Secondary School', 'Third level or higher')
levels(demog$browser)<-  c('Chrome&Edge', 'Chrome', 'Edge', 'Firefox', 'Other', 'Safari')

demographic_summary <-demog %>%
  group_by(ID, sex) %>%
  summarise(age=mean(age))

mean(demographic_summary$age)
sd(demographic_summary$age)

summary(demog$sex)
summary(demog$normal_vision)
summary(demog$normal_hearing)
summary(demog$completed_edu)
summary(demog$level_edu)
summary(demog$browser)

#GIP_data 
names(gip_data)

#SHAPE - for each condition individually
#baseline
#more to add: which motion/shape came first - ex"condition_motion_order.thisN" - strategy for each routine to check if correct
colsSb <- c("participant","v","stimA","stimB","corrAns","group","key_resp_shapeB.keys","key_resp_shapeB.rt")
data_Sb <- gip_data[colsSb]
m_data2 <- data_Sb[!duplicated(data_Sb), ]
datafinal <- m_data2[complete.cases(m_data2),]
datafinal$participant <- as.factor(datafinal$participant)
levels(datafinal$participant)  
data_Sb <- datafinal
data_Sb$accuracy <-  ifelse(data_Sb$key_resp_shapeB.keys == data_Sb$corrAns, 1,0)
data_Sb$relevant_dimension <- "Shape"
colnames(data_Sb)[1] <- 'ID'
colnames(data_Sb)[2] <- 'version'
colnames(data_Sb)[6] <- 'condition'
colnames(data_Sb)[8] <- 'RTms'
colnames(data_Sb)[9] <- 'accuracy'
data_Sb$stimA <- as.factor(data_Sb$stimA)
levels(data_Sb$stimA) <- c("1","2","3","4")
data_Sb$stimB <- as.factor(data_Sb$stimB)
levels(data_Sb$stimB) <- c("1","2","3","4")
data_Sb$RTms <- data_Sb$RTms*1000
#clean dataset
colsSb2<- c("ID","version","relevant_dimension","condition","stimA","stimB","accuracy","RTms")
data_Sb<- data_Sb[colsSb2]

#correlation
colsSc <- c("participant","v","stimA","stimB","corrAns","group","key_resp_shapeC.keys","key_resp_shapeC.rt")
data_Sc <- gip_data[colsSc]
m_data2 <- data_Sc[!duplicated(data_Sc), ]
datafinal <- m_data2[complete.cases(m_data2),]
datafinal$participant <- as.factor(datafinal$participant)
levels(datafinal$participant)  
data_Sc <- datafinal
data_Sc$accuracy <-  ifelse(data_Sc$key_resp_shapeC.keys == data_Sc$corrAns, 1,0)
data_Sc$relevant_dimension <- "Shape"
colnames(data_Sc)[1] <- 'ID'
colnames(data_Sc)[2] <- 'version'
colnames(data_Sc)[6] <- 'condition'
colnames(data_Sc)[8] <- 'RTms'
colnames(data_Sc)[9] <- 'accuracy'
data_Sc$stimA <- as.factor(data_Sc$stimA)
levels(data_Sc$stimA) <- c("360rotation_4","jump_1","swing_2","vibration_3")
data_Sc$stimB <- as.factor(data_Sc$stimB)
levels(data_Sc$stimB)<- c("360rotation_4","jump_1","swing_2","vibration_3")
data_Sc$RTms <- data_Sc$RTms*1000
#clean dataset
colsSc2<- c("ID","version","relevant_dimension","condition","stimA","stimB","accuracy","RTms")
data_Sc<- data_Sc[colsSc2]

#filtering
colsSf <- c("participant","v","stimA","stimB","corrAns","group","key_resp_shapeF.keys","key_resp_shapeF.rt")
data_Sf <- gip_data[colsSf]
m_data2 <- data_Sf[!duplicated(data_Sf), ]
datafinal <- m_data2[complete.cases(m_data2),]
datafinal$participant <- as.factor(datafinal$participant)
levels(datafinal$participant)  
data_Sf <- datafinal
data_Sf$accuracy <-  ifelse(data_Sf$key_resp_shapeF.keys == data_Sf$corrAns, 1,0)
data_Sf$relevant_dimension <- "Shape"
colnames(data_Sf)[1] <- 'ID'
colnames(data_Sf)[2] <- 'version'
colnames(data_Sf)[6] <- 'condition'
colnames(data_Sf)[8] <- 'RTms'
colnames(data_Sf)[9] <- 'accuracy'
data_Sf$stimA <- as.factor(data_Sf$stimA)
levels(data_Sf$stimA) <- c("360rotation_2", "360rotation_4","jump_1", "jump_3",
                          "swing_2","swing_4","vibration_1","vibration_3")
data_Sf$stimB <- as.factor(data_Sf$stimB)
levels(data_Sf$stimB) <- c("360rotation_2", "360rotation_4","jump_1", "jump_3",
                           "swing_2","swing_4","vibration_1","vibration_3")
data_Sf$RTms <- data_Sf$RTms*1000
colsSf2<- c("ID","version","relevant_dimension","condition","stimA","stimB","accuracy","RTms")
data_Sf<- data_Sf[colsSf2]
shape_df <- rbind(data_Sb, data_Sc, data_Sf)

#MOTION
#baseline
colsMb <- c("participant","v","stimA","stimB","corrAns","group","key_resp_motionB.keys","key_resp_motionB.rt")
data_Mb <- gip_data[colsMb]
m_data2 <- data_Mb[!duplicated(data_Mb), ]
datafinal <- m_data2[complete.cases(m_data2),]
datafinal$participant <- as.factor(datafinal$participant)
levels(datafinal$participant)  
data_Mb <- datafinal
data_Mb$accuracy <-  ifelse(data_Mb$key_resp_motionB.keys == data_Mb$corrAns, 1,0)
data_Mb$relevant_dimension <- "Motion"
colnames(data_Mb)[1] <- 'ID'
colnames(data_Mb)[2] <- 'version'
colnames(data_Mb)[6] <- 'condition'
colnames(data_Mb)[8] <- 'RTms'
colnames(data_Mb)[9] <- 'accuracy'
data_Mb$stimA <- as.factor(data_Mb$stimA)
levels(data_Mb$stimA) <- c("360rotation","jump","swing","vibration")
data_Mb$stimB <- as.factor(data_Mb$stimB)
levels(data_Mb$stimB) <- c("360rotation","jump","swing","vibration")
data_Mb$RTms <- data_Mb$RTms*1000
#clean dataset
colsMb2<- c("ID","version","relevant_dimension","condition","stimA","stimB","accuracy","RTms")
data_Mb<- data_Mb[colsMb2]

#correlation
colsMc <- c("participant","v","stimA","stimB","corrAns","group","key_resp_motionC.keys","key_resp_motionC.rt")
data_Mc <- gip_data[colsMc]
m_data2 <- data_Mc[!duplicated(data_Mc), ]
datafinal <- m_data2[complete.cases(m_data2),]
datafinal$participant <- as.factor(datafinal$participant)
levels(datafinal$participant)  
data_Mc <- datafinal
data_Mc$accuracy <-  ifelse(data_Mc$key_resp_motionC.keys == data_Mc$corrAns, 1,0)
data_Mc$relevant_dimension <- "Motion"
colnames(data_Mc)[1] <- 'ID'
colnames(data_Mc)[2] <- 'version'
colnames(data_Mc)[6] <- 'condition'
colnames(data_Mc)[8] <- 'RTms'
colnames(data_Mc)[9] <- 'accuracy'
data_Mc$stimA <- as.factor(data_Mc$stimA)
levels(data_Mc$stimA) <- c("360rotation_4","jump_1","swing_2","vibration_3")
data_Mc$stimB <- as.factor(data_Mc$stimB)
levels(data_Mc$stimB)<- c("360rotation_4","jump_1","swing_2","vibration_3")

data_Mc$RTms <- data_Mc$RTms*1000
#clean dataset
colsMc2<- c("ID","version","relevant_dimension","condition","stimA","stimB","accuracy","RTms")
data_Mc<- data_Mc[colsMc2]

#filtering
colsMf <- c("participant","v","stimA","stimB","corrAns","group","key_resp_motionF.keys","key_resp_motionF.rt")
data_Mf <- gip_data[colsMf]
m_data2 <- data_Mf[!duplicated(data_Mf), ]
datafinal <- m_data2[complete.cases(m_data2),]
datafinal$participant <- as.factor(datafinal$participant)
levels(datafinal$participant)  
data_Mf <- datafinal
data_Mf$accuracy <-  ifelse(data_Mf$key_resp_motionF.keys == data_Mf$corrAns, 1,0)
data_Mf$relevant_dimension <- "Motion"
colnames(data_Mf)[1] <- 'ID'
colnames(data_Mf)[2] <- 'version'
colnames(data_Mf)[6] <- 'condition'
colnames(data_Mf)[8] <- 'RTms'
colnames(data_Mf)[9] <- 'accuracy'
data_Mf$stimA <- as.factor(data_Mf$stimA)
levels(data_Mf$stimA) <- c("360rotation_2", "360rotation_4","jump_1", "jump_3",
                      "swing_2","swing_4","vibration_1","vibration_3")
data_Mf$stimB <- as.factor(data_Mf$stimB)
levels(data_Mf$stimB) <-c("360rotation_2", "360rotation_4","jump_1", "jump_3",
                          "swing_2","swing_4","vibration_1","vibration_3")
data_Mf$RTms <- data_Mf$RTms*1000
#clean dataset
colsMf2<- c("ID","version","relevant_dimension","condition","stimA","stimB","accuracy","RTms")
data_Mf<- data_Mf[colsMf2]
#combine dataset
motion_df <- rbind(data_Mb, data_Mc, data_Mf)

#final datasets
setwd("C:\\Users\\marti\\OneDrive - TCDUD.onmicrosoft.com\\Documents\\Studies\\Data\\MOC_mov\\GIP\\analysis_JUNE25\\df")
write.table(shape_df, file = "C:\\Users\\marti\\OneDrive - TCDUD.onmicrosoft.com\\Documents\\Studies\\Data\\MOC_mov\\GIP\\analysis_JUNE25\\df\\RDshape.csv",  sep= ",")
write.table(motion_df, file = "C:\\Users\\marti\\OneDrive - TCDUD.onmicrosoft.com\\Documents\\Studies\\Data\\MOC_mov\\GIP\\analysis_JUNE25\\df\\RDmotion.csv",  sep= ",")

####clean datasets####
shape_df
shape_df$condition <- factor(shape_df$condition)
levels(shape_df$condition) <-c("Baseline","Correlation", "Filtering")
motion_df
motion_df$condition <- factor(motion_df$condition)
levels(motion_df$condition) <-c("Baseline","Correlation", "Filtering")

final_df <- rbind(shape_df, motion_df)
final_df$relevant_dimension <- as.factor(final_df$relevant_dimension)
levels(final_df$relevant_dimension)
final_df$condition <- factor(final_df$condition)
levels(final_df$condition)
final_df$error_rate <- (1 - final_df$accuracy)
final_df$error_rate100 <- final_df$error_rate*100
final_df <- merge(demog,final_df, by = 'ID')

##exclusion criteria reaction times (RTs) shorter than 150 ms or longer than 2,800 ms, and to remove error trials
# Assuming your dataset is called final_df and the variable for RT is RTms
# and there's a variable indicating error trials called 'error' (1 for error, 0 for correct)
# Step 1: Calculate the number of trials before filtering
total_trials <- nrow(final_df)
#Step 2: Calculate the number of error trials before filtering
total_error_trials <- final_df %>%
  filter(error_rate == 1) %>%
  nrow()
#Step 3: Calculate the error rate before filtering
error_rate_before <- (total_error_trials / total_trials) * 100
#Step 4: Filter out RTs shorter than 150 ms or longer than 2800 ms
filtered_df <- final_df %>%
  filter(RTms >= 250 & RTms <= 2500)
#Step 5: Calculate the number of trials after filtering
remaining_trials <- nrow(filtered_df)
#Step 6: Calculate the amount of data excluded
excluded_trials <- total_trials - remaining_trials
excluded_percentage <- (excluded_trials / total_trials) * 100
#Step 7: Calculate the number of error trials after filtering
remaining_error_trials <- filtered_df %>%
  filter(error_rate == 1) %>%
  nrow()
#Step 8: Calculate the error rate after filtering
error_rate_after <- (remaining_error_trials / remaining_trials) * 100
# Print the results
cat("Total number of trials:", total_trials, "\n")
cat("Number of trials after filtering:", remaining_trials, "\n")
cat("Number of trials excluded:", excluded_trials, "\n")
cat("Percentage of trials excluded:", round(excluded_percentage, 2), "%\n")
cat("Number of error trials before filtering:", total_error_trials, "\n")
cat("Error rate before filtering:", round(error_rate_before, 2), "%\n")
cat("Number of error trials after filtering:", remaining_error_trials, "\n")
cat("Error rate after filtering:", round(error_rate_after, 2), "%\n")
#
final_df <- filtered_df
write.table(final_df, file = "C:\\Users\\marti\\OneDrive - TCDUD.onmicrosoft.com\\Documents\\Studies\\Data\\MOC_mov\\GIP\\analysis_JUNE25\\df\\final_df.csv",  sep= ",")

#dataset without filtering - RG
final_dfGA <- final_df %>% 
  filter(condition != "Filtering")
levels(final_dfGA$condition)
write.table(final_dfGA, file = "C:\\Users\\marti\\OneDrive - TCDUD.onmicrosoft.com\\Documents\\Studies\\Data\\MOC_mov\\GIP\\analysis_JUNE25\\df\\final_dfRG.csv",  sep= ",")

#dataset without correlation - GI
shape_df.1<- rbind(data_Sb, data_Sf)
motion_df.1<- rbind(data_Mb,data_Mf)
final_dfGIP <- rbind(shape_df.1, motion_df.1)
final_dfGIP$relevant_dimension <-as.factor(final_dfGIP$relevant_dimension)
levels(final_dfGIP$relevant_dimension) 
final_dfGIP$condition <-as.factor(final_dfGIP$condition)
levels(final_dfGIP$condition) <- c("Baseline","Filtering","Baseline","Filtering")
final_dfGIP$error_rate <- (1 - final_dfGIP$accuracy)
# Step 1: Calculate the number of trials before filtering
total_trials <- nrow(final_dfGIP)
#Step 2: Calculate the number of error trials before filtering
total_error_trials <- final_dfGIP %>%
  filter(error_rate == 1) %>%
  nrow()
#Step 3: Calculate the error rate before filtering
error_rate_before <- (total_error_trials / total_trials) * 100
#Step 4: Filter out RTs shorter than 150 ms or longer than 2800 ms
filtered_df <- final_dfGIP %>%
  filter(RTms >= 250 & RTms <= 2500)
#Step 5: Calculate the number of trials after filtering
remaining_trials <- nrow(filtered_df)
#Step 6: Calculate the amount of data excluded
excluded_trials <- total_trials - remaining_trials
excluded_percentage <- (excluded_trials / total_trials) * 100
#Step 7: Calculate the number of error trials after filtering
remaining_error_trials <- filtered_df %>%
  filter(error_rate == 1) %>%
  nrow()
#Step 8: Calculate the error rate after filtering
error_rate_after <- (remaining_error_trials / remaining_trials) * 100
# Print the results
cat("Total number of trials:", total_trials, "\n")
cat("Number of trials after filtering:", remaining_trials, "\n")
cat("Number of trials excluded:", excluded_trials, "\n")
cat("Percentage of trials excluded:", round(excluded_percentage, 2), "%\n")
cat("Number of error trials before filtering:", total_error_trials, "\n")
cat("Error rate before filtering:", round(error_rate_before, 2), "%\n")
cat("Number of error trials after filtering:", remaining_error_trials, "\n")
cat("Error rate after filtering:", round(error_rate_after, 2), "%\n")
#
final_dfGIP <- filtered_df
write.table(final_dfGIP, file = "C:\\Users\\marti\\OneDrive - TCDUD.onmicrosoft.com\\Documents\\Studies\\Data\\MOC_mov\\GIP\\analysis_JUNE25\\df\\final_dfGIP.csv",  sep= ",")

